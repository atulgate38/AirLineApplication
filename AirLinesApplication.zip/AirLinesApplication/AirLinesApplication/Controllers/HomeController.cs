﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AirLinesApplication.Models;
namespace AirLinesApplication.Controllers
{
   
    public class HomeController : Controller
    {


        USERLOGINEntities21 db = new USERLOGINEntities21();
        USERLOGINEntities13 db2 = new USERLOGINEntities13();
        USERLOGINEntities9 db3 = new USERLOGINEntities9();
       USERLOGINEntities22 db4 = new USERLOGINEntities22();
        USERLOGINEntities23 db5 = new USERLOGINEntities23();
       

        // GET: Home
        public ActionResult Index()
        {
          return View();
        }
        public ActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(userinfo user)
        {
                Session["Id"] = user.Id.ToString();
                Session["Username"] = user.Username.ToString();
                Session["Cpassword"] = user.CPassword.ToString();
                Session["Age"] = user.Age.ToString();
                db.userinfoes.Add(user);
                db.SaveChanges();

               return RedirectToAction("Login");
        }
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(userinfo user)
        {
            var checkLogin = db.userinfoes.Where(x=>x.Username.Equals(user.Username)&& x.UPassword.Equals(user.UPassword) ).FirstOrDefault();
            if(checkLogin!=null)
            {
                Session["Id"] = user.Id.ToString();
                Session["Username1"] = user.Username.ToString();
                Session["UPassword"] = user.UPassword.ToString();
                return RedirectToAction("BookFlight");
            }
            else
            {
                ViewBag.Notification = "New User Found,please sign up!";
            }
            return View();
        }
      
       

        public ActionResult BookFlight(Add_Flight flight)
        {
                var res = db4.Add_Flight.ToList();
                return View(res);
           
        }
        public ActionResult BookUserInfo()
        {
            return View();
        }
        [HttpPost]
       
      public ActionResult BookUserInfo(Flight_book flight_Book)
        {
            Session["FirstName"] =flight_Book.FirstName.ToString();
            Session["LastName"] = flight_Book.LastName.ToString();
            Session["MobileNo"] = flight_Book.MobileNo.ToString();
            Session["EmailId"] = flight_Book.EmailId.ToString();
            Session["Date"] = flight_Book.Date.ToString();

            db5.Flight_book.Add(flight_Book);
            db5.SaveChanges();
            return RedirectToAction("History");
        }
         public ActionResult History()
        {
            var res = db5.Flight_book.ToList();
            return View(res);
        }

       
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(Admin admin)
        {
            var checkDetails = db3.Admins.Where(x => x.AdminName.Equals(admin.AdminName) && x.AdminPassword.Equals(admin.AdminPassword)).FirstOrDefault();
            if (checkDetails != null)
            {
                Session["AdminName"] = admin.AdminName.ToString();
                Session["AdminPassword"] = admin.AdminPassword.ToString();
                return RedirectToAction("AddFlight");
            }
            else
            {
                ViewBag.Notification = "New Admin Found,No Access!";
            }
            return View();
        }
       
        public ActionResult AddFlight()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddFlight(Add_Flight add_Flight)
        {
            using (db4)
            {
                db4.Add_Flight.Add(add_Flight);
                db4.SaveChanges();
            }
            ModelState.Clear();
            ViewBag.SuccessMessage = "Route added suucessfully";
            return RedirectToAction("Login");

        }
        public ActionResult Cancel(int Id)
        {
            using (db5)
            {
                return View(db5.Flight_book.Where(x => x.Id == Id).FirstOrDefault());
            }
               
        }
        [HttpPost]
        public ActionResult Cancel(BookTicket book)
        {
            try
            {
                var UserRecord = (db5.Flight_book.Where(x => x.Id == book.Id)).FirstOrDefault();
                db5.Flight_book.Remove(UserRecord);
                db5.SaveChanges();
                return RedirectToAction("Login");
            }
            catch
            {
                return View();
            }
           
        }
        public ActionResult DeleteFlight()
        {
            var res = db4.Add_Flight.ToList();
            return View(res);
            
        }

        public ActionResult DeleteFlight1(int FlightId)
        {
            using (db4)
            {
                return View(db4.Add_Flight.Where(x => x.FlightId == FlightId).FirstOrDefault());
            }

        }
        [HttpPost]
        public ActionResult DeleteFlight1(Add_Flight flight)
        {
            try
            {
                var UserRecord11 = (db4.Add_Flight.Where(x => x.FlightId == flight.FlightId)).FirstOrDefault();
                db4.Add_Flight.Remove(UserRecord11);
                db4.SaveChanges();
                return RedirectToAction("Login");
            }
            catch
            {
                return View();
            }

        }

    }
}